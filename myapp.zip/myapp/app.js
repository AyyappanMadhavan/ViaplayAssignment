var express = require('express');
var request = require('request');
var querystring = require("querystring");
var app     = express();
var async = require('async');


var viaplayIMDBIdGet = '';

app.get('/getTrailer', function(req, res){

  //Step 1: Get the url from the request that comes in as querystring. Assumption is that always the resource link comes in as a complete URL.
         // This is the viaplay resource link url
         // Parse the response and get the IMDB id of the resource.  	
  //Step 2: Use TMDB API /find to get the details of the movie using the IMDB id
         // TMDB /find API takes IMDB Id as external id and the api_key
         // This returns the TMDB details of the resource.
         // Get the TMDB Id from the response.
  //Step 3: Use TMDB API /get to get the trailers for the movie	
         // TMDB /get API has /videos operation that provides the trailers and related videos of the requested resource
         // Get the first obj in the response [Assumption is that the first object in the array is the youtube source
         // Get the key and append to the youtube base url to get the Trailer URL of the resource requsted.
         
  //Note: Any error in the step. Returns an error message.
  
  var qs = querystring.parse(req.url.split("?")[1]);
  var urlToGetIMDBId = qs.movieLink;
  viaplayIMDBIdGet = urlToGetIMDBId;
  console.log(viaplayIMDBIdGet);
  
  operations = [];
  operations.push(makeViaplayRequest);
  operations.push(makeTMDBFind);
  operations.push(makeTMDBGet);
  	
	async.waterfall(operations, function(error, resp){
	    if(!error){
	           var trailerURL='http://www.youtube.com/watch?v=';
	           var jsonObj = JSON.parse(resp.body);
	           urlkey = jsonObj.results[0].key;
	           
	           var finalURLToReturn = trailerURL+urlkey	
	           
	           console.log(trailerURL+urlkey);	
	           res.writeHead(200, {"Content-Type": "text/plain"});
	           res.write(finalURLToReturn); 
    		   res.end();
	      }else{
	         console.log('Sorry unable to fetch the trailer for the movie!!Come back later!!');
	          res.writeHead(200, {"Content-Type": "text/plain"});
	          res.write('Sorry unable to fetch the trailer for the movie!!Come back later!!'); 
    		  res.end();
  	      }
	});
});


function makeViaplayRequest(callback) {
    console.log('Making Viaplay Request '+viaplayIMDBIdGet);
    request(viaplayIMDBIdGet, function(error, response){
    	callback(null, response);
    });
   
}

function makeTMDBFind(response, callback) {
	var jsonObj = JSON.parse(response.body);
	imdbId = jsonObj._embedded["viaplay:blocks"][0]._embedded["viaplay:product"].content.imdb.id;
	console.log(imdbId);
	var tmdbIDURL = 'https://api.themoviedb.org/3/find/'+imdbId+'?external_source=imdb_id&api_key=cc619c8d75e1d86447167bf1cb188b93'; 
	console.log('Making TMDB Find Request '+tmdbIDURL);
	request(tmdbIDURL, function(error, response){
		callback(null, response);
	});
}

function makeTMDBGet(response,callback) {
	var tmdbId;
	       var jsonObj = JSON.parse(response.body);
	       tmdbId = jsonObj.movie_results[0].id;
	        console.log(tmdbId);	
		
		//Next use /get/trailers with the TMDB id.
	var trailerURL = 'http://api.themoviedb.org/3/movie/'+tmdbId+'/videos?api_key=cc619c8d75e1d86447167bf1cb188b93';
	console.log('Making TMDB Get Request '+trailerURL);
	request(trailerURL, function(error, response){
		callback(null,response);
	});
}



app.listen('8081')

console.log('Server on port 8081');